        function makeSingle( $f ){
            var b = [], e, n, tag;
            if ( $f.length === 1 ) return $f;
            tag = $f[0].nodeName;
            n = $f.attr('name')
            $f.each( function(i, e){
                b.push( e.value );
                e.parentNode.removeChild( e );
            } );
            e = document.createElement( tag );
            e.setAttribute( 'type', 'hidden' );
            e.setAttribute( 'name', n );
            e.value = b.join( ' ' );
            document.querySelector( 'form#cctv-modules' ).appendChild( e );
            return $( e );
        }
        function cleanComponentField( f ){
            var $f = findField( f );
            if( !$f.length ){
                    $( 'form#cctv-modules' ).append('<input type="hidden" value="" name="./' + f + '">');
            }else{
                $f = makeSingle( $f );
                encodeField( $f );
            }
        }
        function createField(n, v, t){
            var $form = $('form#cctv-modules');
            $form.append('<input type="' + ( t || 'hidden' ) + '" value="' + v + '" name="./' + n + '">');
        }
        function findField( f, $form ){
            if ( !$form ){
                $form = $('form#cctv-modules');
            }
            return $form.find( '[name=./' + f + ']' );
        }
        function encodeField( $f ){
            $f.val( encodeValue( $f.val() ) );
            return $f;
        }
        function encodeValue( v ){
            return v ? v.replace( /</g, '&lt;' ).replace( />/g, '&gt;' ) : '';
        }
        function decodeValue( v ){
            return v ? v.replace( /&lt;/g, '<' ).replace( /&gt;/g, '>' ) : '';
        }
        function isHidden( content ){
            var t = content.substring( 0, 20 );
            return content && t === '<!-- sni::hidden -->';           
        }
        function haveIFrame( content ){
            var f;
            if ( content.iframe ){
                f = decodeValue( content.iframe );
            }
            return f;
        }
        function fillHead( content ){
            var h = decodeValue( content.head );
            
            if ( isHidden( h ) ) return;
            if (h){
                $('head').append( h );
            }
        }
        function fillRegion( content ){
            var r = $.trim( decodeValue( content.region ) ), rid, $region;
            
            if ( isHidden( r ) ) return; 
            rid = $.trim( decodeValue( content.regionId ) ); //indicates content left or right rail
            if (rid){
                $region = $( '#sni-bd div' ); //left or right rail region container
                $region.attr( 'id', rid ); 
                if( r ){
                    $region.html( r );
                    $region =$region.find( 'div' );               
                }                             
            }else{
                $region = $( '#sni-bd' );
                if( r ){
                    $region.html( r );
                    $region = $region.find( 'div#moduleGoesHere' ).closest(':not(div#moduleGoesHere)');               
                }   
            }
                      
            return $region;                     
        }
        function fillCode( $region, content ){
            var c = decodeValue( content.code ), bclass, f;
            
            if ( isHidden( c ) ){
                f = haveIFrame( content );
                if ( f ){
                   $region.html( f ); 
                }
            }else{
                bclass = $.trim( decodeValue( content.bodyClass ) );
            
                if ( bclass ){
                    $( 'body' ).addClass( bclass );
                }
                $region.html( c );
            }
            
            return c;           
        }
/*        
        function doInserts(inserts){
            $.each(inserts, function(i, insert){
                var t = insert.appendTo,
                appendTo = true,
                c = insert.data,
                $t;
                if( !t ){
                    t = insert.target;
                    appendTo = false;
                }
                if ( !t ) return;
                $t = $(t);
                if ( !$t.length ) return;
                if ( $t[0].nodeName.toUpperCase() === 'IFRAME' ){
                    $t = $t.contents().find( insert.select );
                    if ( !$t.length ) return;
                }
                if( !appendTo ){
                    $t.html(c);
                }else{
                    $(c).appendTo( $t );
                }
            });
        }
*/
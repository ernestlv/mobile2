//exec after usr click OK btn false stops submit action
function beforeSubmitHandler( dialog ){
    var xForm = dialog.form, //extjs form
    text = xForm.findField( './text' ).getValue(),
    url = xForm.findField( './url' ).getValue(),
    target = xForm.findField( './target' ).getValue();

    findField( 'locationText' ).val( text ); //find html field
    findField( 'location' ).val( url );
    findField( 'locationTarget' ).val( target );
    dialog.hide();
     
    return false; 
}

//exec after dialog is shown
function loadContentHandler( dialog ){
    var xForm = dialog.form;
    xForm.findField( './text' ).setValue( findField( 'locationText' ).val() );
    xForm.findField( './url' ).setValue( findField( 'location' ).val() );
    xForm.findField( './target' ).setValue( findField( 'locationTarget' ).val() );

    return true;
}